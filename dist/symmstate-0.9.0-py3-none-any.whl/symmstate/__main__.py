from symmstate.cli import cli  # Adjust the import path as needed

cli()
