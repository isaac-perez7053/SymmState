from symmstate.vasp.vasp_unit_cell import VaspUnitCell


class VaspConvergenceFile(VaspUnitCell):
    def __init__(self):
        super().__init__()
